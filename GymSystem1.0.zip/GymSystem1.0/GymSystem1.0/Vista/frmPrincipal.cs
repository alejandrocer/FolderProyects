﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymSystem1._0.Vista
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }
        #region [  Metodos para botones  ]
        private void ptbCerrar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Decea cerrar GymSystem?", "GymSystem", MessageBoxButtons.YesNo) == DialogResult.Yes)
                Application.Exit();
        }

        private void ptbMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        int LX, LY, SW, SH;
        private void pnlMenu_Click(object sender, EventArgs e)
        {
            if (pnlMenuVertical.Width == 57)
            {
                pnlMenuVertical.Width = 250;
            }
            else

                pnlMenuVertical.Width = 57;
        }

        private void ptbRestaurar_Click(object sender, EventArgs e)
        {
            this.Size = new Size(SW, SH);
            this.Location = new Point(LX, LY);
            ptbMaximizar.Visible = true;
            ptbRestaurar.Visible = false;
        }

        private void ptbMaximizar_Click(object sender, EventArgs e)
        {
            LX = this.Location.X;
            LY = this.Location.Y;
            SW = this.Size.Width;
            SH = this.Size.Height;
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
            ptbMaximizar.Visible = false;
            ptbRestaurar.Visible = true;
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void pnlHeader_MouseMove(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            MostrarLogo();
        }

        private void MostrarLogo()
        {
            AbrirFormInPanel(new frmLogo());
        }

        private void AbrirFormInPanel(object formHijo)
        {
            if (this.pnlContenedor.Controls.Count > 0)
                this.pnlContenedor.Controls.RemoveAt(0);
            Form fh = formHijo as Form;
            fh.TopLevel = false;
            fh.FormBorderStyle = FormBorderStyle.None;
            fh.Dock = DockStyle.Fill;
            this.pnlContenedor.Controls.Add(fh);
            this.pnlContenedor.Tag = fh;
            fh.Show();
        }
        #endregion

        private void btnClientes_Click(object sender, EventArgs e)
        {
            frmRegistroClientes frmRegistro = new frmRegistroClientes(0);
            frmRegistro.FormClosed += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frmRegistro);
        }
        frmListadoClientes frmListado = new frmListadoClientes();

        private void btnPagos_Click(object sender, EventArgs e)
        {
            frmPagos pagos = new frmPagos();
            pagos.FormClosed += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(pagos);
        }

        private void btnReporte_Click(object sender, EventArgs e)
        {
            frmListado = new frmListadoClientes();
            frmListado.FormClosed += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frmListado);
        }

        private void mostrarlogoAlCerrarForm(object sender, FormClosedEventArgs e)
        {
            
            if(frmListado.IdClienteSeleccionado > 0)
            {
                AbrirFormEditar(frmListado.IdClienteSeleccionado);
            }
            else
                MostrarLogo();
        }

        public void AbrirFormEditar(int IdClienteSeleccionado)
        {
            frmRegistroClientes frmClientes = new frmRegistroClientes(IdClienteSeleccionado);
            frmClientes.FormClosed += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frmClientes);
            frmListado = new frmListadoClientes();
        }
    }
}
