﻿using GymSystem1._0.Controlador;
using GymSystem1._0.Modelo;
using System;
using System.Windows.Forms;

namespace GymSystem1._0.Vista
{
    public partial class frmListadoClientes : Form, IVistaClientes
    {
        public int IdClienteSeleccionado { get; set; }
        ControlClientes _controles;
        public frmListadoClientes()
        {
            InitializeComponent();
            _controles = new ControlClientes(this);
            _controles.cargarVista();
        }
        public void AgregarUsuarioGrid(Cliente cliente)
        {
            this.dgvUsuarios.Rows.Add(cliente.ID, cliente.Nombre, cliente.ApellidoP + " " + cliente.ApellidoM,
                cliente.FechaInicial.ToShortDateString(), cliente.FechaFinal.ToShortDateString(), cliente.Membresia, cliente.Status);
        }

        public void EliminarUsuarioGrid(int IdEliminar)
        {
            throw new NotImplementedException();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEditarCliente_Click(object sender, EventArgs e)
        {
            IdClienteSeleccionado = int.Parse(dgvUsuarios.SelectedCells[0].Value.ToString());
            this.Close();
        }
    }
}
