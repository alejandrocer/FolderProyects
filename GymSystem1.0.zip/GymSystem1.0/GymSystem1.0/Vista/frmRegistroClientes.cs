﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymSystem1._0.Vista
{
    public partial class frmRegistroClientes : Form
    {
        public frmRegistroClientes(int IdCliente)
        {
            InitializeComponent();

            txtID.Text = IdCliente > 0 ? IdCliente.ToString() : "0";
        }

        private void txtNombre_Leave(object sender, EventArgs e)
        {
            if (txtNombre.Text == "")
            {
                txtNombre.Text = "Nombre";
                txtNombre.ForeColor = Color.DimGray;
            }
        }

        private void txtApellidoP_Enter(object sender, EventArgs e)
        {
            if (txtApellidoP.Text == "Apellido Paterno")
            {
                txtApellidoP.Text = "";
                txtApellidoP.ForeColor = Color.LightGray;
            }
        }

        private void txtApellidoP_Leave(object sender, EventArgs e)
        {
            if (txtApellidoP.Text == "")
            {
                txtApellidoP.Text = "Apellido Paterno";
                txtApellidoP.ForeColor = Color.DimGray;
            }
        }

        private void txtApellidoMaterno_Leave(object sender, EventArgs e)
        {
            if (txtApellidoMaterno.Text == "")
            {
                txtApellidoMaterno.Text = "Apellido Materno";
                txtApellidoMaterno.ForeColor = Color.DimGray;
            }
        }

        private void txtApellidoMaterno_Enter(object sender, EventArgs e)
        {
            if (txtApellidoMaterno.Text == "Apellido Materno")
            {
                txtApellidoMaterno.Text = "";
                txtApellidoMaterno.ForeColor = Color.LightGray;
            }
        }

        private void rbtFemenino_CheckedChanged(object sender, EventArgs e)
        {
            rbtFemenino.ForeColor = Color.LightGray;
            rbtMasculino.ForeColor = Color.DimGray;
        }

        private void rbtMasculino_CheckedChanged(object sender, EventArgs e)
        {
            rbtFemenino.ForeColor = Color.DimGray;
            rbtMasculino.ForeColor = Color.LightGray;
        }

        private void pcbCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliente registrado correctamente", "Registro Cliente", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
        }

        private void txtNombre_Enter(object sender, EventArgs e)
        {
            if (txtNombre.Text == "Nombre")
            {
                txtNombre.Text = "";
                txtNombre.ForeColor = Color.LightGray;
            }
        }
    }
}
