﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymSystem1._0.Modelo
{
    public class ConsultasClientes
    {

        public IList ConsultaClientes()
        {
            IList clientes = new ArrayList
            {
                new Cliente { ID = "1", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Mensual", Status ="Pagado" },
                new Cliente { ID = "2", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Mensual", Status ="No pagado" },
                new Cliente { ID = "3", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Visita", Status ="Pagado" },
                new Cliente { ID = "4", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Quincenal", Status ="Pagado" },
                new Cliente { ID = "5", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Semanal", Status ="Pagado" },
                new Cliente { ID = "6", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Semanal", Status ="No Pagado" },
                new Cliente { ID = "7", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Semanal", Status ="Pagado" },
                new Cliente { ID = "8", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Visita", Status ="Pagado" },
                new Cliente { ID = "9", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Quincenal", Status ="Pagado" },
                new Cliente { ID = "10", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Quincenal", Status ="Pagado" },
                new Cliente { ID = "11", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Mensual", Status ="No Pagado" },
                new Cliente { ID = "12", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Mensual", Status ="No Pagado" },
                new Cliente { ID = "13", Nombre = "Fulanito", ApellidoP = "de", ApellidoM = "Tal", FechaFinal = DateTime.Parse(DateTime.Now.ToShortDateString()), FechaInicial = DateTime.Parse(DateTime.Now.ToShortDateString()), Membresia = "Mensual", Status ="Pagado" }
            };
            return clientes;
        }
    }
}
