﻿using GymSystem1._0.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymSystem1._0.Controlador
{
    public class ControlClientes
    {
        IVistaClientes _vista;
        ConsultasClientes _clientes;
        public ControlClientes(IVistaClientes vista)
        {
            _vista = vista;
            _clientes = new ConsultasClientes();
        }

        public void cargarVista()
        {
            var clientes = _clientes.ConsultaClientes();

            if (clientes.Count > 0)
            {
                foreach (Cliente client in clientes)
                {
                    _vista.AgregarUsuarioGrid(client);
                }
            }
        }
    }
}
